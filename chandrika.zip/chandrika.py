import streamlit as st
import pandas as pd
import numpy as np
from sklearn.linear_model import LinearRegression
import matplotlib.pyplot as plt

# ==========================================
# PAGE CONFIG
# ==========================================

st.set_page_config(
    page_title="Hospital Resource Allocation Predictor System",
    page_icon="🏥",
    layout="wide"
)
st.markdown("""
<style>

.stApp{
    background:#f4f8fc;
}

/* Header */
.header{
background:linear-gradient(90deg,#1d4ed8,#2563eb,#3b82f6);
padding:30px;
border-radius:15px;
text-align:center;
color:white;
margin-bottom:20px;
box-shadow:0px 5px 15px rgba(0,0,0,0.2);
}

.header h1{
margin:0;
font-size:40px;
}

.header p{
font-size:18px;
margin-top:10px;
}

/* Metric Cards */

div[data-testid="metric-container"]{
background:white;
padding:15px;
border-radius:15px;
box-shadow:0px 4px 12px rgba(0,0,0,.15);
border:1px solid #e5e7eb;
}

</style>
""", unsafe_allow_html=True)
# ==========================================
# CONSTANTS
# ==========================================

TOTAL_BEDS = 500
TOTAL_DOCTORS = 40
TOTAL_NURSES = 80
TOTAL_EQUIPMENT = 200

# ==========================================
# HEADER
# ==========================================

st.markdown("""
<div class="header">
<h1>🏥 Hospital Resource Allocation Predictor System</h1>
<p>AI-Based Resource Management Dashboard</p>
</div>
""", unsafe_allow_html=True)


# ==========================================
# METRICS
# ==========================================

c1,c2,c3,c4 = st.columns(4)

with c1:
    st.metric("🛏 Beds", TOTAL_BEDS)

with c2:
    st.metric("👨‍⚕️ Doctors", TOTAL_DOCTORS)

with c3:
    st.metric("👩‍⚕️ Nurses", TOTAL_NURSES)

with c4:
    st.metric("🩺 Equipment", TOTAL_EQUIPMENT)

# ==========================================
# INPUTS
# ==========================================

col1,col2,col3,col4 = st.columns(4)

with col1:
    department = st.selectbox(
        "Department",
        ["General","ICU","Emergency",
         "Cardiology","Orthopedic"]
    )

with col2:
    shift = st.selectbox(
        "Shift",
        ["Morning","Afternoon","Night"]
    )

with col3:
    available_beds = st.number_input(
        "Available Beds",
        min_value=0,
        value=100
    )

with col4:
    expected_patients = st.number_input(
        "Expected Patients",
        min_value=0,
        value=50
    )

if "run_prediction" not in st.session_state:
    st.session_state.run_prediction = False

st.markdown("<br>", unsafe_allow_html=True)

if st.button(
    "🔍 Predict Resource Allocation",
    use_container_width=True
):
    st.session_state.run_prediction = True

run_prediction = st.session_state.run_prediction

# ==========================================
# PREDICTION
# ==========================================

if run_prediction:

    days = np.arange(1,31).reshape(-1,1)

    # Data used for ML model
    patients = np.array([
       116, 117, 118, 118, 119,
       119, 116, 116, 116, 122,
       123, 123, 124, 117, 119,
       121, 120, 120, 121, 120,
       122, 121, 120, 122, 121,
       123, 122, 121, 123, 122 
    ]) 

    model=LinearRegression()
    model.fit(days,patients)

    score=model.score(days,patients)

    future_days=pd.DataFrame({
        "day":np.arange(31,38)
    })

    future_days["predicted_patients"]=(
        model.predict(
            future_days[["day"]]
        )
    ).astype(int)
    
    # ==========================================
    # AI PATIENT DEMAND FORECAST GRAPH
    # ==========================================

    graph_days = np.arange(1, 31)
    predicted_curve = [
       116, 117, 118, 118, 119,
       119, 116, 116, 116, 122,
       123, 123, 124, 117, 119,
       121, 120, 120, 121, 120,
       122, 121, 120, 122, 121,
       123, 122, 121, 123, 122 
    ]
    

    fig1, ax1 = plt.subplots(figsize=(8,4))

    ax1.plot(
        graph_days,
        predicted_curve,
        linewidth=3,
        color="#1f77b4",
        marker="o",
        markersize=5
    )

    ax1.fill_between(
        graph_days,
        predicted_curve,
        alpha=0.15,
        color="#1f77b4"
    )

    ax1.set_title(
        "AI Patient Demand Forecast",
        fontsize=15,
        fontweight="bold"
    )

    ax1.set_xlabel("Days", fontsize=11)

    ax1.set_ylabel("Patients", fontsize=11)
    ax1.set_ylim(112, 124)        
    ax1.set_yticks(range(112, 125, 4))

    ax1.grid(True, alpha=0.3)

    ax1.spines["top"].set_visible(False)
    ax1.spines["right"].set_visible(False)

    ax1.set_xlim(1,30)

    fig1.tight_layout()
    # Don't display the graph here
    tab1,tab2,tab3 =st.tabs([

        "📈 Patient Demand Prediction",
        "🏥 Medical Resource Management",
        "🛏 Bed Dashboard",
        
    ])
    with tab1:
        left_panel, right_panel = st.columns([1, 2], gap="large")
        with left_panel:

            with st.container(border=True):

                st.subheader("📝 Today's Patient Entry")
                c1, c2 = st.columns(2)

                with c1:
                    inpatient = st.number_input("Today's Inpatients", min_value=0, value=120)

                with c2:
                    outpatient = st.number_input("Today's Outpatients", min_value=0, value=250)

                st.metric("👥 Total Patients", inpatient + outpatient)

                st.divider()
                combined_df = pd.DataFrame({

                    "Week": ["Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"],
                    "Past Week Patient Arrivals": [132,148,141,157,145,162,150],
                    "Forecast Weekly Patient Demand": [154,146,163,151,169,158,166]
                })

                with st.container(border=True):
                    st.subheader("📊 Past Week vs Forecast Weekly Patient Demand")

                    st.dataframe(
                        combined_df,
                        width="stretch",
                        hide_index=True
                    )

        st.divider()
        with right_panel:
            with st.container(border=True):
                st.subheader("🎯 Prediction Accuracy")
                st.metric(
                    "Model Accuracy",
                    f"{round(score * 100, 2)}%"
                )
                
                st.divider()

                st.subheader("📊 AI Patient Demand Forecast")

                st.pyplot(fig1)

                st.divider()

                peak_day = combined_df.loc[
                    combined_df["Forecast Weekly Patient Demand"].idxmax()
                ]

            with st.container(border=True):

                st.subheader("🚨 Peak Admission Period")

                st.metric(
                    "Peak Admission Day",
                    peak_day["Week"],
                    f"{peak_day['Forecast Weekly Patient Demand']} Patients"
                )


            avg_patients = int(combined_df["Forecast Weekly Patient Demand"].mean())
            highest = combined_df["Forecast Weekly Patient Demand"].max()
            lowest = combined_df["Forecast Weekly Patient Demand"].min()

            c1, c2, c3 = st.columns(3)
            with c1:
                st.metric("Average Patients", avg_patients)

            with c2:
                st.metric("Highest Prediction", highest)

            with c3:
                st.metric("Lowest Prediction", lowest)
    with tab2:
        left_col, center_col, right_col = st.columns(3, gap="medium")
        c1, c2, c3, c4 = st.columns(4)

        with c1:
            st.metric("🩸 Blood Units Available", "320 Units")

        with c2:
            st.metric("💉 Equipment Available", "156 Items")

        with c3:
            st.metric("🔔 Critical Alerts", "2")

        with c4:
            st.metric("📋 Low Stock Items", "3")
        with left_col:
            with st.container(border=True):
                st.subheader("🩸 Blood Bank Management")

                blood_groups = ["A+","A-","B+","B-","AB+","AB-","O+","O-"]

    # Initialize blood stock
                if "blood_stock" not in st.session_state:
                    st.session_state.blood_stock = {
                        "A+":40,
                        "A-":8,
                        "B+":25,
                        "B-":6,
                        "AB+":12,
                        "AB-":4,
                        "O+":55,
                        "O-":7
                    }

                st.subheader("🩸 Blood Inventory")

                blood_df = pd.DataFrame({
                    "Blood Group": list(st.session_state.blood_stock.keys()),
                    "Available Units": list(st.session_state.blood_stock.values())
               })

                st.dataframe(
                    blood_df,
                    use_container_width=True,
                    hide_index=True
                 )

                st.divider()

                selected_group = st.selectbox(
                    "Select Blood Group",
                    blood_groups
                )

                change = st.number_input(
                    "Units",
                    min_value=1,
                    value=1
                )

                c1, c2 = st.columns(2)

                with c1:
                    if st.button("➕ Add Units", use_container_width=True):
                        st.session_state.blood_stock[selected_group] += change
                        st.rerun()

                with c2:
                    if st.button("➖ Remove Units", use_container_width=True):
                        if st.session_state.blood_stock[selected_group] >= change:
                            st.session_state.blood_stock[selected_group] -= change
                            st.rerun()
                        else:
                            st.error("Not enough units available.")
        
        with center_col:

            with st.container(border=True):

                st.subheader("🩸 Blood Inventory Status")

                blood_df = pd.DataFrame({
                    "Blood Group": list(st.session_state.blood_stock.keys()),
                    "Available Units": list(st.session_state.blood_stock.values())
                })

                fig, ax = plt.subplots(figsize=(6,4))

                ax.barh(
                    blood_df["Blood Group"],
                    blood_df["Available Units"]
                )

                ax.set_xlabel("Available Units")
                ax.set_title("Blood Inventory")

                st.pyplot(fig)

                
                
        with right_col:

            with st.container(border=True):

                st.subheader("📦 Medical Equipment Tracking")
                if "equipment_df" not in st.session_state:

                     st.session_state.equipment_df = pd.DataFrame({

                        "Equipment":[
                        "Ventilator",
                        "Oxygen Cylinder",
                        "ECG Machine",
                        "Wheelchair",
                        "Defibrillator"
                    ],

                    "Total":[20,60,15,40,10],

                    "In Use":[16,45,9,22,6]

                })

                st.session_state.equipment_df["Available"] = (
                st.session_state.equipment_df["Total"] -
                st.session_state.equipment_df["In Use"]
                )
                equipment_df = st.session_state.equipment_df
                st.dataframe(
                    equipment_df[["Equipment","Available","In Use"]],
                    use_container_width=True,
                    hide_index=True
                )

                c1, c2, c3 = st.columns(3)

                with c1:
                    st.metric("Total", equipment_df["Total"].sum())

                with c2:
                    st.metric("In Use", equipment_df["In Use"].sum())

                with c3:
                    st.metric("Available", equipment_df["Available"].sum())

                st.divider()

        # ==========================================
        # TWO COLUMNS BELOW TABLES
        # ==========================================

        alloc_col, update_col, table_col = st.columns([1,1,1.2], gap="medium")

        # ==========================================
        # EQUIPMENT ALLOCATION
        # ==========================================

        with alloc_col:

            st.subheader("⚙ Equipment Allocation")

            selected_equipment = st.selectbox(
                "Select Equipment",
                equipment_df["Equipment"],
                key="equipment_select_tab2"
            )

            required_units = st.number_input(
                "Required Units",
                min_value=1,
                value=1,
                key="equipment_units_tab2"
            )

            available_units = int(
                equipment_df.loc[
                    equipment_df["Equipment"] == selected_equipment,
                    "Available"
                ].values[0]
            )

            if st.button(
                "Allocate Equipment",
                use_container_width=True,
                key="allocate_equipment_tab2"
            ):

                if required_units <= available_units:

                    equipment_df.loc[
                        equipment_df["Equipment"] == selected_equipment,
                        "In Use"
                    ] += required_units

                    equipment_df.loc[
                        equipment_df["Equipment"] == selected_equipment,
                        "Available"
                    ] -= required_units

                    st.session_state.equipment_df = equipment_df

                    st.success("Equipment Allocated Successfully.")

                else:

                    st.error(f"Only {available_units} units available.")

        # ==========================================
        # UPDATE EQUIPMENT STOCK
        # ==========================================

        with update_col:

            st.subheader("✏ Update Equipment Stock")

            update_equipment = st.selectbox(
                "Equipment Name",
                equipment_df["Equipment"],
                key="update_equipment"
            )

            current_total = int(
                equipment_df.loc[
                    equipment_df["Equipment"] == update_equipment,
                    "Total"
                ].values[0]
            )

            current_inuse = int(
                equipment_df.loc[
                    equipment_df["Equipment"] == update_equipment,
                    "In Use"
                ].values[0]
            )

            st.write(f"Current Total : **{current_total}**")
            st.write(f"Currently In Use : **{current_inuse}**")

            new_total = st.number_input(
                "New Total Stock",
                min_value=current_inuse,
                value=current_total,
                key="new_total_stock"
            )

            new_inuse = st.number_input(
                "New In Use",
                min_value=0,
                max_value=new_total,
                value=current_inuse,
                key="new_inuse_stock"
            )

            if st.button(
                "Update Equipment",
                use_container_width=True,
                key="update_equipment_button"
            ):

                equipment_df.loc[
                    equipment_df["Equipment"] == update_equipment,
                    "Total"
                ] = new_total

                equipment_df.loc[
                    equipment_df["Equipment"] == update_equipment,
                    "In Use"
                ] = new_inuse

                equipment_df.loc[
                    equipment_df["Equipment"] == update_equipment,
                    "Available"
                ] = new_total - new_inuse

                st.session_state.equipment_df = equipment_df

                st.success("Equipment Updated Successfully.")
        with table_col:

            st.subheader("📋 Updated Equipment Inventory")

            st.dataframe(
                st.session_state.equipment_df[
                    ["Equipment", "Total", "In Use", "Available"]
                ],
                use_container_width=True,
                hide_index=True
            )

            c1, c2, c3 = st.columns(3)

            with c1:
                st.metric(
                    "Total",
                    st.session_state.equipment_df["Total"].sum()
                )

            with c2:
                st.metric(
                    "In Use",
                    st.session_state.equipment_df["In Use"].sum()
                )

            with c3:
                st.metric(
                    "Available",
                    st.session_state.equipment_df["Available"].sum()
                ) 
    with tab3:

        st.subheader("🛏 AI Hospital Bed Dashboard")

    # ==========================================
    # INITIALIZE BED DATA
    # ==========================================

        if "bed_df" not in st.session_state:

            st.session_state.bed_df = pd.DataFrame({

                "Department": [
                    "General",
                    "ICU",
                    "Emergency",
                    "Cardiology",
                    "Orthopedic"
                ],

                "Total Beds": [150, 50, 80, 120, 100],

                "Occupied": [110, 45, 62, 80, 70]

            })

        bed_df = st.session_state.bed_df

        bed_df["Available"] = (
            bed_df["Total Beds"] - bed_df["Occupied"]
        )

        bed_df["Occupancy %"] = (
            bed_df["Occupied"] / bed_df["Total Beds"] * 100
        ).round(1)

        total_beds = bed_df["Total Beds"].sum()
        occupied = bed_df["Occupied"].sum()
        available = bed_df["Available"].sum()
        maintenance = 20

    # ==========================================
    # SUMMARY CARDS
    # ==========================================

        c1, c2, c3, c4 = st.columns(4)

        with c1:
            st.metric("🛏 Total Beds", total_beds)

        with c2:
            st.metric("🔴 Occupied Beds", occupied)

        with c3:
            st.metric("🟢 Available Beds", available)

        with c4:
            st.metric("🛠 Maintenance", maintenance)

        st.divider()

    # ==========================================
    # PATIENT ADMISSION & DISCHARGE
    # ==========================================

        st.subheader("🧑‍⚕️ Patient Admission & Discharge Management")

        c1, c2, c3 = st.columns(3)

        with c1:
            patient_department = st.selectbox(
                "Department",
                bed_df["Department"],
                key="patient_department"
            )

        with c2:
            new_patients = st.number_input(
                "New Patients",
                min_value=0,
                value=0
            )

        with c3:
            discharged_patients = st.number_input(
                "Discharged Patients",
                min_value=0,
                value=0
            )

        if st.button(
            "Update Patient Records",
            use_container_width=True
        ):

            current = int(
                bed_df.loc[
                    bed_df["Department"] == patient_department,
                    "Occupied"
                ].values[0]
            )

            total = int(
                bed_df.loc[
                    bed_df["Department"] == patient_department,
                    "Total Beds"
                ].values[0]
            )

            updated = current + new_patients - discharged_patients

            updated = max(0, min(updated, total))

            bed_df.loc[
                bed_df["Department"] == patient_department,
                "Occupied"
            ] = updated

            bed_df["Available"] = (
                bed_df["Total Beds"] - bed_df["Occupied"]
            )

            bed_df["Occupancy %"] = (
                bed_df["Occupied"] / bed_df["Total Beds"] * 100
            ).round(1)

            st.session_state.bed_df = bed_df

            st.success("Patient Records Updated Successfully.")

            st.rerun()

        st.divider()

    # Refresh values after update

        bed_df = st.session_state.bed_df

        total_beds = bed_df["Total Beds"].sum()
        occupied = bed_df["Occupied"].sum()
        available = bed_df["Available"].sum()
         # ==========================================
    # AI-BASED BED ALLOCATION
    # ==========================================

        st.subheader("🤖 AI-Based Bed Allocation Recommendation")

        recommendation_df = bed_df[
            ["Department", "Available", "Occupancy %"]
        ].copy()

        recommendation_df["Recommendation"] = recommendation_df[
            "Occupancy %"
        ].apply(
            lambda x:
            "Allocate More Beds"
            if x >= 85
            else "Monitor Capacity"
            if x >= 70
            else "Sufficient Capacity"
        )

        st.dataframe(
            recommendation_df,
            use_container_width=True,
            hide_index=True
        )

        st.divider()


    # ==========================================
    # BED OVERVIEW, TABLE & BAR CHART
    # ==========================================

        col1, col2, col3 = st.columns(3)

        with col1:

            st.subheader("🥧 Bed Occupancy Overview")

            fig, ax = plt.subplots(figsize=(3.5, 3.5))

            ax.pie(
                [occupied, available, maintenance],
                labels=["Occupied", "Available", "Maintenance"],
                autopct="%1.1f%%",
                startangle=90
            )

            ax.axis("equal")

            st.pyplot(fig)

        with col2:

            st.subheader("📋 Department Bed Details")

            st.dataframe(
                bed_df,
                use_container_width=True,
                hide_index=True,
                height=300
            )

        with col3:

            st.subheader("📊 Available Beds by Department")

            fig2, ax2 = plt.subplots(figsize=(4, 3.5))

            ax2.bar(
                bed_df["Department"],
                bed_df["Available"]
            )

            ax2.set_ylabel("Available Beds")
            ax2.set_xlabel("Department")

            plt.xticks(rotation=20)

            st.pyplot(fig2)

        st.divider()

   
    # ==========================================
    # OVERALL OCCUPANCY
    # ==========================================

        occupancy = occupied / total_beds

        st.subheader("📈 Overall Bed Occupancy")

        st.progress(occupancy)

        st.write(
            f"Hospital Occupancy Rate : {(occupancy * 100):.1f}%"
        )
